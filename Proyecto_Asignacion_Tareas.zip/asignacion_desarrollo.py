from pulp import LpMinimize, LpProblem, LpVariable, lpSum, LpStatus

devs = ["Dev1","Dev2","Dev3","Dev4"]
tasks = ["T1","T2","T3","T4","T5","T6"]

t = {"T1":8, "T2":12, "T3":5, "T4":10, "T5":6, "T6":4}
C = {"Dev1":20, "Dev2":25, "Dev3":15, "Dev4":18}

c = {
  ("Dev1","T1"):9, ("Dev1","T2"):14, ("Dev1","T3"):6, ("Dev1","T4"):11, ("Dev1","T5"):7, ("Dev1","T6"):5,
  ("Dev2","T1"):8, ("Dev2","T2"):12, ("Dev2","T3"):7, ("Dev2","T4"):10, ("Dev2","T5"):8, ("Dev2","T6"):6,
  ("Dev3","T1"):10,("Dev3","T2"):15,("Dev3","T3"):5, ("Dev3","T4"):12, ("Dev3","T5"):9, ("Dev3","T6"):7,
  ("Dev4","T1"):7, ("Dev4","T2"):13,("Dev4","T3"):8, ("Dev4","T4"):11, ("Dev4","T5"):6, ("Dev4","T6"):4
}

model = LpProblem("Asignacion_Tareas_Dev", LpMinimize)
y = {(i,j): LpVariable(f"y_{i}_{j}", cat="Binary") for i in devs for j in tasks}

model += lpSum(c[(i,j)] * y[(i,j)] for i in devs for j in tasks)

for j in tasks:
    model += lpSum(y[(i,j)] for i in devs) == 1, f"Asignacion_{j}"

for i in devs:
    model += lpSum(t[j] * y[(i,j)] for j in tasks) <= C[i], f"Capacidad_{i}"

model.solve()

print("Estado:", LpStatus[model.status])
print("Asignaciones:")
for j in tasks:
    for i in devs:
        if y[(i,j)].value() == 1:
            print(f" - {j} -> {i}")
print("Costo total (objetivo):", model.objective.value())